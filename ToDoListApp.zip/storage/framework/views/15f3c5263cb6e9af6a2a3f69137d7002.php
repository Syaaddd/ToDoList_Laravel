<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Todos')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-full mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="sm:flex sm:items-center justify-between p-6 bg-gray-100">
                    <h2 class="text-lg font-medium">Manage Todos</h2>
                    <div class="mt-4 sm:mt-0">
                        <a href="<?php echo e(route('todos.create')); ?>"
                            style="display: inline-flex; align-items: center; padding: 8px 16px; color: white; background-color: #4f46e5; border-radius: 0.375rem; font-weight: bold;"
                            aria-label="Create a new todo item">
                            <span class="material-icons mr-2"> add_circle </span> Create
                        </a>
                    </div>
                </div>

                <div class="p-6 text-gray-900">
                    <?php if(Session::has('alert-success')): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                            <?php echo e(Session::get('alert-success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(!is_null($todos) && count($todos) > 0): ?>
                        <div class="overflow-hidden border border-gray-300 rounded-lg">
                            <table class="min-w-full bg-white">
                                <thead>
                                    <tr class="bg-gray-200 text-gray-700 uppercase text-sm">
                                        <th class="py-3 px-2 md:px-6 text-left">Title</th>
                                        <th class="py-3 px-2 md:px-6 text-left hidden md:table-cell">Description</th>
                                        <th class="py-3 px-2 md:px-6 text-center">Completed</th>
                                        <th class="py-3 px-2 md:px-6 text-center hidden md:table-cell">Created At</th>
                                        <th class="py-3 px-2 md:px-6 text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-700">
                                    <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-gray-100 border-b">
                                            <td class="py-4 px-2 md:px-6"><?php echo e($todo->title); ?></td>
                                            <td class="py-4 px-2 md:px-6 hidden md:table-cell"><?php echo e($todo->description); ?></td>
                                            <td class="py-4 px-2 md:px-6 text-center">
                                                <?php if($todo->is_completed): ?>
                                                    <span class="inline-block px-2 md:px-3 py-1 text-xs font-semibold bg-green-100 text-green-700 rounded-full">Completed</span>
                                                <?php else: ?>
                                                    <span class="inline-block px-2 md:px-3 py-1 text-xs font-semibold bg-red-100 text-red-700 rounded-full">Incomplete</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="py-4 px-2 md:px-6 text-center hidden md:table-cell"><?php echo e($todo->created_at->format('d M, Y')); ?></td>
                                            <td class="py-4 px-2 md:px-6 text-center flex md:block justify-center gap-1">
                                                <a href="<?php echo e(route('todos.edit', $todo->id)); ?>"
                                                   class="inline-block px-4 py-1 text-white bg-blue-500 hover:bg-blue-600 rounded text-xs font-semibold">
                                                   Edit
                                                </a>
                                                <a href="<?php echo e(route('todos.show', $todo->id)); ?>"
                                                   class="inline-block px-4 py-1 text-white bg-green-500 hover:bg-green-600 rounded text-xs font-semibold">
                                                   View
                                                </a>
                                                <form method="post" action="<?php echo e(route('todos.destroy', $todo->id)); ?>" class="inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <input type="hidden" name="todo_id" value="<?php echo e($todo->id); ?>">
                                                    <input
                                                        type="submit"
                                                        class="px-4 py-1 text-white bg-red-500 hover:bg-red-600 rounded text-xs font-semibold"
                                                        value="Delete"
                                                    >

                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-6 text-gray-600">
                            <p>No Todos available. Click "Create" to add one.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\sites\ToDoListApp\resources\views/todos/index.blade.php ENDPATH**/ ?>